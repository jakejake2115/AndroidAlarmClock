package edu.ilstu;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import androidx.fragment.app.Fragment;

public class ContentFragment extends Fragment {
    Button b1 = null;
    TimePicker p1 = null;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.content_fragment, container, false);
        b1 = (Button) inflater.inflate(R.layout.activity_main,container,false.view.findViewById(R.id.button);
        p1= (TimePicker) view.findViewById(R.id.timePicker);
        b1.setOnClickListener(this);
        return view;
    }

        @Override
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(), "Alarm Set", Toast.LENGTH_LONG).show();

        }

}
